from fastapi import APIRouter
from app.database.neo4j import driver

router = APIRouter(prefix="/neo4j")

@router.get("/nodes")
def get_nodes():
    with driver.session() as session:
        result = session.run("MATCH (n) RETURN labels(n), properties(n) LIMIT 200")
        data = []
        for r in result:
            data.append({
                "labels": r[0],
                "properties": r[1]
            })
        return data


@router.get("/relations")
def get_relations():
    with driver.session() as session:
        result = session.run("""
            MATCH (a)-[r]->(b)
            RETURN labels(a), type(r), labels(b) LIMIT 200
        """)
        data = []
        for r in result:
            data.append({
                "from": r[0],
                "relation": r[1],
                "to": r[2]
            })
        return data
