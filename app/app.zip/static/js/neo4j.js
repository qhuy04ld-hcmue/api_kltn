async function loadGraph(){
    const res = await fetch("/neo4j/graph");
    const data = await res.json();

    const nodes = new vis.DataSet(
        data.nodes.map(n=>({
            id:n.id,
            label:n.label,
            color:getColor(n.type)
        }))
    );

    const edges = new vis.DataSet(data.edges);

    new vis.Network(
        document.getElementById("graph"),
        {nodes,edges},
        {physics:true}
    );
}

function getColor(type){
    const colors={
        Class:"#ff7675",
        Subject:"#74b9ff",
        Topic:"#55efc4",
        Lesson:"#ffeaa7"
    }
    return colors[type]||"#ccc";
}

loadGraph();
